//-----------------------------------------------------------------------------
// 
// Sample Name: Video Texture Sample
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
//-----------------------------------------------------------------------------


Description
===========
  This sample demonstrates placing video on a 3D surface.

Path
====
  Source:     DXSDK\Samples\C#\AudioVideo\Texture
  Executable: DXSDK\Samples\C#\AudioVideo\Bin

User's Guide
============
  Open a file and play it.

