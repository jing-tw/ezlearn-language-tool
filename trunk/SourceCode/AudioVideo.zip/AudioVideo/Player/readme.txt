//-----------------------------------------------------------------------------
// 
// Sample Name: AudioVideo Player Sample
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
// 
//-----------------------------------------------------------------------------


Description
===========
  This sample provides simple playback of audio and video.

Path
====
  Source:     DXSDK\Samples\C#\AudioVideo\Player
  Executable: DXSDK\Samples\C#\AudioVideo\Bin

User's Guide
============
  Open a file and play it.

